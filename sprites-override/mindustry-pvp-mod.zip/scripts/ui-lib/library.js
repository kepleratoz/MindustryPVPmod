// UI Library for PVP Mod

const ui = {
    // Add a button to the HUD
    addButton(name, text, clicked) {
        const button = extend(ImageButton, {});
        button.clicked(() => clicked());
        button.defaults().size(140, 50);
        
        const table = new Table();
        table.top().right();
        table.defaults().size(140, 50).right().pad(5);
        table.add(button);
        
        // Add the table to the HUD
        Vars.ui.hudGroup.addChild(table);
    },
    
    // Create a simple dialog with a message
    showDialog(title, message) {
        const dialog = new BaseDialog(title);
        dialog.cont.add(message).row();
        dialog.addCloseButton();
        dialog.show();
    },
    
    // Create a table with colored text
    coloredText(text, color) {
        return `[${color}]${text}[]`;
    }
};

module.exports = ui; 